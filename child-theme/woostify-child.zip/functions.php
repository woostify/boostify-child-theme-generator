<?php
/**
 * Woostify Child Theme functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Woostify Child Theme
 * @since 1.0.0
 */
