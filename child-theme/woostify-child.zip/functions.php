<?php
/**
 * Woostify Child Theme functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Woostify Child Theme
 * @since 1.0.0
 */
/**
 * Enqueue styles
 */
function enqueue_parent_theme_style() {
wp_enqueue_style( 'undefined-parent-theme-css', get_template_directory_uri() . '/style.css', array(), '1.0.0', 'all' );
}
add_action( 'wp_enqueue_scripts', 'enqueue_parent_theme_style', 15 );
