<?php
/**
 * Boostify Child Theme functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Boostify Child Theme
 * @since 1.1
 */
